"""Shared utilities."""
