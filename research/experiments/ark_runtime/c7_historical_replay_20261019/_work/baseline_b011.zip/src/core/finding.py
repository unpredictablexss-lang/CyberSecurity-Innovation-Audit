from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any


@dataclass
class Finding:
    rule_id: str
    title: str
    vulnerability_type: str
    cwe: str
    severity: str
    confidence: str
    file_path: str
    line: int
    function: Optional[str]
    evidence: str
    explanation: str
    remediation: str
    status: str = "candidate"
    function_start_line: Optional[int] = None
    function_end_line: Optional[int] = None
    context_start_line: Optional[int] = None
    context_end_line: Optional[int] = None
    context: Optional[str] = None
    context_status: str = "unresolved"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
